//
//  card3.swift
//  parcial2_jorgebautista
//
//  Created by MacOsX on 3/16/24.
//
import SwiftUI

struct card3: View {
    var body: some View {
        ZStack(alignment: .top){
            RoundedRectangle(cornerRadius: 15)
                .frame(width: 300, height:170)
                .foregroundColor(colores2)
            
            ZStack(alignment: .bottom){
                VStack(spacing:0){
                    Group{
                        Text("ETPS4")
                            .multilineTextAlignment(.center)
                            .font(.system(size: 24,weight:.semibold))
                            .foregroundColor(.white)
                            .shadow(radius: 15)
                            .alignmentGuide(.bottom) { d in d[.bottom] }
                    }
                }
                .frame(height: 170)
            }
        }
    }
}

struct card3_Previews: PreviewProvider {
    static var previews: some View {
        elementos()
    }
}

