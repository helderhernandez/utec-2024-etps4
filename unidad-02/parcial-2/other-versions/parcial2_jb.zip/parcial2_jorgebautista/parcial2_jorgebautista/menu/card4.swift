import SwiftUI

struct card4: View {
    let colores3 = Color(#colorLiteral(red: 0.5725490451, green: 0, blue: 0.2313725501, alpha: 1))
    
    var body: some View {
        ZStack(alignment: .top){
            RoundedRectangle(cornerRadius: 15)
                .frame(width: 300, height:170)
                .foregroundColor(colores3) // Cambiado a colores3
            
            ZStack(alignment: .bottom){
                VStack(spacing:0){
                    Group{
                        Text("CICLO 01-2024")
                            .multilineTextAlignment(.center)
                            .font(.system(size: 24,weight:.semibold))
                            .foregroundColor(.white)
                            .shadow(radius: 15)
                            .alignmentGuide(.bottom) { d in d[.bottom] }
                    }
                }
                .frame(height: 170)
            }
        }
    }
}

struct card4_Previews: PreviewProvider {
    static var previews: some View {
        elementos()
    }
}
