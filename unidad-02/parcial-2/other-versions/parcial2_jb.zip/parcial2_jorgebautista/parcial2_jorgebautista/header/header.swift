import SwiftUI

struct header: View {
    @State private var searchText = ""

    var body: some View {
        HStack {
            Image("logo_utec")
                .resizable()
                .scaledToFit()
                .frame(width: 40, height: 40)
                .clipShape(Circle())
            
            Spacer()
            
            TextField("JORGE BAUTISTA", text: $searchText)
                .padding(8)
            
            Circle()
                .fill(Color.yellow)
                .frame(width: 40, height: 40)
                .overlay(
                    Image(systemName: "magnifyingglass")
                        .font(.system(size: 18))
                        .foregroundColor(.black)
                )
                .padding(8)
                .onTapGesture {
                    // Aquí puedes agregar la acción que deseas que ocurra cuando se haga clic en el botón de la lupa
                    print("Botón de la lupa presionado")
                }
            
            Circle()
                .fill(Color.yellow)
                .frame(width: 40, height: 40)
                .overlay(
                    Image(systemName: "message")
                        .font(.system(size: 18))
                        .foregroundColor(.black) // Icono en color blanco
                )
                .padding(8)
        }
        .padding(.horizontal)
    }
}

struct header_Previews: PreviewProvider {
    static var previews: some View {
        header()
    }
}
