//
//  parcial2_jorgebautistaApp.swift
//  parcial2_jorgebautista
//
//  Created by MacOsX on 3/16/24.
//

import SwiftUI

@main
struct parcial2_jorgebautistaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
