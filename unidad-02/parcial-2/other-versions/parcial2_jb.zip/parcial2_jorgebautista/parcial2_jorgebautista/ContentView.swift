//
//  ContentView.swift
//  parcial2_jorgebautista
//
//  Created by MacOsX on 3/16/24.
//
/*
import SwiftUI

struct ContentView: View {

    @State private var textoBusqueda = ""

    var body: some View {
    ZStack(alignment: .top) {
    RoundedRectangle(cornerRadius: 15)
    .fill(Color(red: 0.978567183, green: 0.6576827168, blue: 0.2109591961))
    .frame(maxWidth: .infinity, maxHeight: .infinity)

    VStack {

    Image("logo_utec")
    .resizable()
    .scaledToFit()
    .frame(width: 200, height: 200)
    .padding()

   
    ZStack {
    RoundedRectangle(cornerRadius: 15)
    .fill(Color.white)
    TextField("Buscar", text: $textoBusqueda)
    .padding()
    .disableAutocorrection(true)
    .autocapitalization(.none)
        
    }
    .padding(.horizontal)

  
    Button(action: {
    print("El mensaje ingresado es: \(textoBusqueda)")
    print("")
    }) {
    ZStack {
    RoundedRectangle(cornerRadius: 15)
    .fill(Color.blue)
    Text("Buscar")
    .foregroundColor(.white)
    .padding()
    }
    }
    .padding(.horizontal)

        
    }
    .padding()
    .navigationBarTitle("Examen Práctico")
    }
    .edgesIgnoringSafeArea(.all)
    }
    }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
*/

import SwiftUI

struct ContentView: View {
var body: some View {
VStack{
ScrollView{
header()
Divider()
    Text("Examen practico")
elementos()
    card2()
    card3()
    card4()
    Divider()

}
}
}
}

struct ContentView_Previews: PreviewProvider {
static var previews: some View {
ContentView()
}
}
