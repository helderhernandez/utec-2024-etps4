//
//  parcial2App.swift
//  parcial2
//
//  Created by MacOsX on 3/16/24.
//

import SwiftUI

@main
struct parcial2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
